package GUI;

import Item.Item;

public interface MyAgentInterface {

//    public void AddItemToInventory(Item i);
    public void StartMasterAgent();
//    public void StopMasterAgent();
//    public void GenerateMap();
}